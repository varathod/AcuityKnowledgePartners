﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Model
{
    public class Company
    {
        public string SNo { get; set; }
        public string CompanyName { get; set; }
        public string Sector { get; set; }
        public string SubSector { get; set; }
        public string Region { get; set; }
        public string NoofEmployees { get; set; }
        public string TotalRevenues { get; set; }
        public string Websites { get; set; }

    }
}
