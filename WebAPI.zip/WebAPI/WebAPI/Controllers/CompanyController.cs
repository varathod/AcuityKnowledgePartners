﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebAPI.Model;
using OfficeOpenXml;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompanyController : ControllerBase
    {

        [Route("Upload")]
        [HttpPost, DisableRequestSizeLimit]
        public async Task<IActionResult> Upload()
        {
            try
            {
                var list = new List<Company>();

                using (var stream = new MemoryStream())
                {
                    var formFile = Request.Form.Files[0];
                    await formFile.CopyToAsync(stream);

                    using (var package = new ExcelPackage(stream))
                    {
                        ExcelWorksheet worksheet = package.Workbook.Worksheets["Companies"];
                        var rowCount = worksheet.Dimension.Rows;

                        for (int row = 2; row <= rowCount; row++)
                        {
                            list.Add(new Company
                            {
                                SNo = worksheet.Cells[row, 1].Value.ToString().Trim(),
                                CompanyName = worksheet.Cells[row, 2].Value.ToString().Trim(),
                                Sector = worksheet.Cells[row , 3].Value.ToString().Trim(),
                                SubSector = worksheet.Cells[row, 4].Value.ToString().Trim(),
                                Region = worksheet.Cells[row, 5].Value.ToString().Trim(),
                                NoofEmployees = worksheet.Cells[row, 6].Value.ToString().Trim(),
                                TotalRevenues = worksheet.Cells[row, 7].Value.ToString().Trim(),
                                Websites = worksheet.Cells[row, 8].Value.ToString().Trim(),
                            });
                        }
                    }
                }

                return Ok(list);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex}");
            }
        }

     
    }
    }

