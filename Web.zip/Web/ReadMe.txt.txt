Angular UI >>

Before Doing ng serve --o please do npm install as because of size of the folder i had to delete node_modules folder.

FYI 
When You will do npm install --save it will automatically generate node_modules folder.
