export class CompanyData {
        sNo :string;
       companyName:string;
       sector:string;
       subSector :string;
       region :string;
       noofEmployees:string;
       totalRevenues :string;
       websites :string;
   
   
}
