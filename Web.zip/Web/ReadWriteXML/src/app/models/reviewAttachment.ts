export class ReviewAttachment {
    fileName: string;
    extension: string;
    uniqueReference: string;
    blobFileName: string;
    blobUrl: string;
    comments?: string;
}