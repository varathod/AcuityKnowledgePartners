import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { throwError, Observable } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { CompanyData } from '../models/companyData';
import * as Excel from "exceljs/dist/exceljs.min.js";
import * as ExcelProper from "exceljs";
import * as fs from 'file-saver';

@Injectable({
    providedIn: 'root'
  })


  export class ExcelService {

    baseUrl:string = 'http://localhost:50345/api/company';
    dataArray = [];

    constructor(private http: HttpClient) {}


  uploadAttachment(formData: FormData): Observable<any> {
    return this.http
      .post(
        this.baseUrl + '/Upload' ,formData
      )
      .pipe(
        tap(data => { }),
        catchError(this.handleError)
      );
  }

  exportEditedExcel(requestData:CompanyData[]):Observable<any>{

    return this.http
    .post(
      this.baseUrl + '/Upload' ,requestData
    )
    .pipe(
      tap(data => { }),
      catchError(this.handleError)
    );

  }

  private handleError(err: HttpErrorResponse) {
    // in a real world app, we may send the server to some remote logging infrastructure
    // instead of just logging it to the console
    let errorMessage = '';
    if (err.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      errorMessage = `An error occurred: ${err.error.message}`;
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      errorMessage = `Server returned code: ${err.status}, error message is: ${
        err.message
        }`;
    }
    return throwError(errorMessage);
    }
    
  
    exportAccountToExcel(excelData: CompanyData[]) {
      this.dataArray = [];
      for (let i = 0; i < excelData.length; i++) {
        let row = Object.keys(excelData[i]).map((key) => {
          return excelData[i][key];
        });
        this.dataArray.push(row);
      }

      this.buildExcel(this.dataArray, 'CompanyData', 'Sample Data'+'.xlsx');
    }

    buildExcel(dataArray: Array<any>, workSheetName: string, fileName: string) {
    
      // Get Headers
      let header: string[] = [];
      if (workSheetName === 'CompanyData') {
        header = this.getHeaders();
      }
  
      // Create workbook and worksheet
      let workbook: ExcelProper.Workbook = new Excel.Workbook();
      let worksheet = workbook.addWorksheet(workSheetName);
      let headerRow = worksheet.addRow(header);
  
      // Formatting Header row
      this.styleHeaderRow(headerRow);
  
      // Add Data and Conditional Formatting
      this.styleDataRows(dataArray, worksheet);
      
  
      // Set columns width
      if (workSheetName === 'CompanyData') {
        this.setColumnWidth(worksheet);
      }
      workbook.xlsx.writeBuffer().then((data: ArrayBuffer) => {
        let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        fs.saveAs(blob, fileName);
      });
    }
    setColumnWidth(worksheet: ExcelProper.Worksheet) {
      worksheet.getColumn(1).width = 15;
      worksheet.getColumn(2).width = 50;
      worksheet.getColumn(3).width = 15;
      worksheet.getColumn(4).width = 25;
      worksheet.getColumn(5).width = 25;
      worksheet.getColumn(6).width = 20;
      worksheet.getColumn(7).width = 25;
      worksheet.getColumn(8).width = 20;
    }
    getHeaders(): Array<string> {
      let headers = [
        'S.No.',
        'Company',
        'Sector',
        'Sub-Sector',
        'Region',
        'No. of Employees',
        'Total Revenues (in $M)',
        'Websites'
      ];
      return headers;
    }
    styleHeaderRow(row: ExcelProper.Row) {
      // Cell Style : Fill and Border
      row.eachCell((cell, number) => {
        cell.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: 'FF0E5ACE' },
          bgColor: { argb: 'FF0E5ACE' }
        };
        cell.font = { name: 'Calibri', bold: true, size: 12, color: { argb: 'FFFFFFFF' } };
        cell.alignment = { vertical: 'middle', horizontal: 'justify' };
        cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
      });
      row.height = 40;
    }

    styleDataRows(dataArray: Array<any>, worksheet: ExcelProper.Worksheet) {
      dataArray.forEach(d => {
        let row = worksheet.addRow(d);
        row.height = 20;
        row.eachCell((cell, number) => {
          cell.font = { name: 'Calibri', size: 11 };
          cell.alignment = { vertical: 'middle' };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };

        });
      });
      }
  
  }
