import { Component, OnInit, Input, Output, EventEmitter, HostListener, ElementRef, OnDestroy, ViewChild, SimpleChanges } from "@angular/core";
import { ExcelService } from 'src/app/services/excel.service';
import { Subscription } from 'rxjs';
import { ReviewAttachment } from 'src/app/models/reviewAttachment';
import { CompanyData } from 'src/app/models/companyData';

@Component({
  selector: 'app-excel',
  templateUrl: './excel.component.html',
  styleUrls: ['./excel.component.less']
})
export class ExcelComponent implements OnInit {

  file: File;
  @ViewChild('fileUpload')
  modelData:CompanyData[]=[];
  isDataLoaded:boolean;
  uploadReviewAttachmentSubscription:Subscription;
  reviewAttachments:ReviewAttachment[];
  myInputFileUpload: ElementRef;
  enableForm:boolean[]=[];
  CompanyNname:string='';

  constructor(private excelService:ExcelService) {
  }

  
  ngOnInit() {
  }


  editForm(id:number,index:number){
    this.enableForm[index] = true;
  }
  
  handleFileInput(fileList: FileList) {
    if(fileList.length === 0) {
      return;
    }

    for(let i=0;i<fileList.length;i++){
      const file =fileList.item(i);

      let formData = new FormData();
      formData.append('file', file);
      //this.spinner.show();
    
      this.uploadReviewAttachmentSubscription = this.excelService.uploadAttachment(formData).subscribe(
        (data) => {
          this.modelData = data;
          this.isDataLoaded = true;
        }
      );
    }
  }

  exportToExcel(){

        this.excelService.exportAccountToExcel(this.modelData);
      
  }
}
